﻿using System.IO;

namespace CopyBinaryFile
{
    public class CopyBinaryFile
    {
        static void Main(string[] args)
        {
            string inputPath = @"..\..\..\copyMe.png";
            string outputPath = @"..\..\..\copyMe-copy.png";

            CopyFile(inputPath, outputPath);
        }

        public static void CopyFile(string inputFilePath, string outputFilePath)
        {
            using (FileStream fsin = new FileStream(inputFilePath, FileMode.Open))
            {
                byte[] input = new byte[fsin.Length];
                int toRead = (int)fsin.Length;
                int bytesRead = 0;
                while (toRead>0)
                {
                    int n = fsin.Read(input, bytesRead, toRead);
                    if (n==0)
                    {
                        break;
                    }
                    bytesRead += n;
                    toRead -= n;
                }
                toRead = input.Length;
                using (FileStream fsout = new FileStream(outputFilePath, FileMode.Create))
                {
                    fsout.Write(input, 0, input.Length);
                }
            }
        }

    }
}

