﻿using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Drones
{
    public class Airfield
    {
        public List<Drone> drones = new List<Drone>();
        public Airfield(string name, int capacity, double landingStrip)
        {
            this.Name = name;
            this.Capacity = capacity;
            this.LandingStrip = landingStrip;
          
        }
        public IReadOnlyCollection<Drone> Drones => drones;
        public string Name { get; set; }
        public int Capacity { get; set; }
        public double LandingStrip { get; set; }
        public int Count { get { return Drones.Count; } }
        public string AddDrone(Drone drone)
        {
            if (drone.Name==null || drone.Brand == null || drone.Range<5 || drone.Range>15)
            {
                return"Invalid drone.";
                
            }
            if (Capacity==Count)
            {
                return"Airfield is full.";
                
            }
                drones.Add(drone);
                return $"Successfully added {drone.Name} to the airfield.";
            
            
        }
        public bool RemoveDrone(string name)
        {
            //int index = 0;
            //bool isExisting = false;
            //for (int i = 0; i < Drones.Count; i++)
            //{
            //    if (drones[i].Name == name)
            //    {
            //        isExisting = true;
            //        index = i;
            //        break;
            //    }
            //}            
            //if (isExisting)
            //{
            //    drones.RemoveAt(index);
            //    return true;
            //}
            //return false;
            
            if (drones.Any(x => x.Name == name))
            {
                Drone toRemove = drones.First(x => x.Name == name);
                drones.Remove(toRemove);
                return true;
            }
            return false;
        }
        public int RemoveDroneByBrand(string brand)
        {
            //int removedCount = 0;
            //int initCount = this.Count;
            ////for (int i = 0; i < initCount; i++)
            ////{
            ////    if (drones[i].Brand == brand)
            ////    {
            ////        drones.RemoveAt(i);
            ////        removedCount++;
            ////        i--;
            ////    }
            ////}
            //int i = 0;
            //while (i!= this.Count)
            //{
            //    if (drones[i].Brand==brand)
            //    {
            //        drones.RemoveAt(i);
            //        removedCount++;
            //        i--;
            //    }
            //    i++;
            //}
            int removedCount = drones.Count(x => x.Brand == brand);
            drones.RemoveAll(x => x.Brand == brand);
            return removedCount;
            
        }
        public Drone FlyDrone(string name)
        {
            //for (int i = 0; i < this.Count; i++)
            //{
            //    if (drones[i].Name == name)
            //    {
            //        drones[i].Available = false;
            //        return drones[i];
            //    }
            //}
            //return null;
            //foreach (var item in drones)
            //{
            //    if (item.Name ==name)
            //    {
            //        item.Available = false;
            //        return item;
            //    }
            //}
            //return null;
            if (drones.Any(x => x.Name == name))
            {
                Drone drone = drones.First(x => x.Name == name);
                drone.Available = false;
                return drone;
            }

            return null;
        }
        public List<Drone> FlyDronesByRange(int range)
        {
            List<Drone> GreaterRangeDrones = drones.FindAll(x => x.Range >= range);
            //for (int i = 0; i < this.Count; i++)
            //{
            //    if (drones[i].Range>=range)
            //    {
            //        drones[i].Available = false;
            //        GreaterRangeDrones.Add(drones[i]);
            //    }
            //}
            //foreach (var item in drones)
            //{
            //    if (item.Range>=range)
            //    {
            //        item.Available = false;
            //        GreaterRangeDrones.Add(item);
            //    }
            //}
            
            GreaterRangeDrones.Select(x => x.Available = false).ToList();
            
            return GreaterRangeDrones;
        }
        public string Report()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Drones available at {this.Name}:");
            for (int i = 0; i < this.Count; i++)
            {
                if (drones[i].Available)
                {
                    sb.AppendLine(drones[i].ToString());
                }
            }
            return sb.ToString().Trim();
        }
    }
}
