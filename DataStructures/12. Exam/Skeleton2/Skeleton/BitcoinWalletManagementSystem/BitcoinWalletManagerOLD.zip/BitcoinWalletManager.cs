using System;
using System.Collections.Generic;
using System.Linq;

namespace BitcoinWalletManagementSystem
{
    public class BitcoinWalletManager : IBitcoinWalletManager
    {
        private Dictionary<string, User> users = new Dictionary<string, User>();
        private Dictionary<string, Wallet> wallets = new Dictionary<string, Wallet>();
        private Dictionary<string, Transaction> transactions = new Dictionary<string, Transaction>();
        public void CreateUser(User user)
        {
            users.Add(user.Id, user);
        }

        public void CreateWallet(Wallet wallet)
        {
            wallets.Add(wallet.Id, wallet);
            users[wallet.UserId].Wallets.Add(wallet);
        }

        public bool ContainsUser(User user)
        {
            return users.ContainsKey(user.Id);
        }

        public bool ContainsWallet(Wallet wallet)
        {
            return wallets.ContainsKey(wallet.Id);
        }

        public IEnumerable<Wallet> GetWalletsByUser(string userId)
        {
            return users[userId].Wallets;
        }

        public void PerformTransaction(Transaction transaction)
        {
            if (!this.ContainsWallet(wallets[transaction.SenderWalletId]) || !this.ContainsWallet(wallets[transaction.ReceiverWalletId]))
            {
                throw new ArgumentException();
            }
            if (wallets[transaction.SenderWalletId].Balance<transaction.Amount)
            {
                throw new ArgumentException();
            }
            wallets[transaction.SenderWalletId].Balance -= transaction.Amount;
            wallets[transaction.ReceiverWalletId].Balance += transaction.Amount;
            transactions.Add(transaction.Id, transaction);
            //users[transaction.SenderWalletId].Wallets.FirstOrDefault(x=>x.UserId==transaction.SenderWalletId).Balance-= transaction.Amount;
            //users[transaction.ReceiverWalletId].Wallets.FirstOrDefault(x=>x.UserId==transaction.ReceiverWalletId).Balance+= transaction.Amount;
        }

        public IEnumerable<Transaction> GetTransactionsByUser(string userId)
        {
            return transactions.Values.Where(x => x.SenderWalletId == wallets.FirstOrDefault(y => y.Value.UserId == userId).Key || x.ReceiverWalletId == wallets.FirstOrDefault(y => y.Value.UserId == userId).Key);
            //var et = new List<Transaction>();
            //foreach (Transaction t in transactions.Values)
            //{
            //    if (t.SenderWalletId == wallets.FirstOrDefault(y => y.Value.UserId == userId).Key || t.ReceiverWalletId== wallets.FirstOrDefault(y => y.Value.UserId == userId).Key)
            //    {
            //        et.Add(t);
            //    }
            //}
            //return et;
        }

        public IEnumerable<Wallet> GetWalletsSortedByBalanceDescending()
        {
            return wallets.Values.OrderByDescending(x=>x.Balance);
        }

        public IEnumerable<User> GetUsersSortedByBalanceDescending()
        {
            return users.Values.OrderByDescending(x=>x.Wallets.Sum(y=>y.Balance));
        }

        public IEnumerable<User> GetUsersByTransactionCount()
        {
            //var a = transactions.Value.ReceiverWalletId;
            return users.Values.OrderByDescending(x => transactions.Count(y => y.Value.ReceiverWalletId==x.Wallets.FirstOrDefault(z => z.UserId == x.Id).Id || y.Value.SenderWalletId == x.Wallets.FirstOrDefault(z => z.UserId == x.Id).Id));
        }
    }
}