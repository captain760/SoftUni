using System;
using System.Collections.Generic;

namespace BitcoinWalletManagementSystem
{
    public class BitcoinWalletManager : IBitcoinWalletManager
    {
        public void CreateUser(User user)
        {
            throw new NotImplementedException();
        }

        public void CreateWallet(Wallet wallet)
        {
            throw new NotImplementedException();
        }

        public bool ContainsUser(User user)
        {
            throw new NotImplementedException();
        }

        public bool ContainsWallet(Wallet wallet)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Wallet> GetWalletsByUser(string userId)
        {
            throw new NotImplementedException();
        }

        public void PerformTransaction(Transaction transaction)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Transaction> GetTransactionsByUser(string userId)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Wallet> GetWalletsSortedByBalanceDescending()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<User> GetUsersSortedByBalanceDescending()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<User> GetUsersByTransactionCount()
        {
            throw new NotImplementedException();
        }
    }
}