using System;
using System.Collections.Generic;

namespace PublicTransportManagementSystem
{
    public class PublicTransportRepository : IPublicTransportRepository
    {
        public void RegisterPassenger(Passenger passenger)
        {
            throw new NotImplementedException();
        }

        public void AddBus(Bus bus)
        {
            throw new NotImplementedException();
        }

        public bool Contains(Passenger passenger)
        {
            throw new NotImplementedException();
        }

        public bool Contains(Bus bus)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Bus> GetBuses()
        {
            throw new NotImplementedException();
        }

        public void BoardBus(Passenger passenger, Bus bus)
        {
            throw new NotImplementedException();
        }

        public void LeaveBus(Passenger passenger, Bus bus)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Passenger> GetPassengersOnBus(Bus bus)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Bus> GetBusesOrderedByOccupancy()
        {
            throw new NotImplementedException();
        }

        public IEnumerable<Bus> GetBusesWithCapacity(int capacity)
        {
            throw new NotImplementedException();
        }
    }
}