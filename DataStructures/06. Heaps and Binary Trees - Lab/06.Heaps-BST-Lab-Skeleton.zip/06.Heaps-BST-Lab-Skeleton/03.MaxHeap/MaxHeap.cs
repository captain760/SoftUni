﻿namespace _03.MaxHeap
{
    using System;
    using System.Collections.Generic;

    public class MaxHeap<T> : IAbstractHeap<T> where T : IComparable<T>
    {
        public int Size => throw new NotImplementedException();

        public void Add(T element)
        {
            throw new NotImplementedException();
        }

        public T ExtractMax()
        {
            throw new NotImplementedException();
        }

        public T Peek()
        {
            throw new NotImplementedException();
        }
    }
}
