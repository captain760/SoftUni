﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace Exam.MovieDatabase
{
    public class MovieDatabase : IMovieDatabase
    {
        private HashSet<Movie> movies = new HashSet<Movie>();
        private HashSet<Actor> actors= new HashSet<Actor>();
        public void AddActor(Actor actor)
        {
            actors.Add(actor);
        }

        public void AddMovie(Actor actor, Movie movie)
        {
            if (!actors.Contains(actor))
            {
                throw new ArgumentException();
            }
            movies.Add(movie);
            actors.FirstOrDefault(x=>x.Id == actor.Id).Movies.Add(movie);
        }

        public bool Contains(Actor actor)
        {
            return actors.Contains(actor);
        }

        public bool Contains(Movie movie)
        {
            return movies.Contains(movie);
        }

        public IEnumerable<Actor> GetActorsOrderedByMaxMovieBudgetThenByMoviesCount()
        {
            return actors.OrderByDescending(x=>x.Movies.Max(x=>x.Budget)).ThenByDescending(x=>x.Movies.Count);
        }

        public IEnumerable<Movie> GetAllMovies()
        {
            return movies;
        }

        public IEnumerable<Movie> GetMoviesInRangeOfBudget(double lower, double upper)
        {
            return movies.Where(x=>x.Budget>=lower && x.Budget<=upper).OrderByDescending(x=>x.Rating);
        }

        public IEnumerable<Movie> GetMoviesOrderedByBudgetThenByRating()
        {
            return movies.OrderByDescending(x=>x.Budget).ThenByDescending(x=>x.Rating);
        }

        public IEnumerable<Actor> GetNewbieActors()
        {
            return actors.Where(x=>x.Movies.Count==0);
        }
    }
}
