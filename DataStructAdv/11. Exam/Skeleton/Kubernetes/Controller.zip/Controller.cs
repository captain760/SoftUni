using System;
using System.Collections.Generic;
using System.Linq;

namespace Kubernetes
{
    public class Controller : IController
    {
        private Dictionary<string, Pod> controlers = new Dictionary<string, Pod>();

        public bool Contains(string podId)
        {
            return controlers.ContainsKey(podId);
        }

        public void Deploy(Pod pod)
        {
            if (!controlers.ContainsKey(pod.Id))
            {
                controlers.Add(pod.Id, pod);
            }
        }

        public Pod GetPod(string podId)
        {
            if (controlers.ContainsKey(podId))
            {
                return controlers[podId];
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public IEnumerable<Pod> GetPodsBetweenPort(int lowerBound, int upperBound)
        {
            return controlers.Values.Where(p => p.Port>= lowerBound && p.Port<=upperBound);
        }

        public IEnumerable<Pod> GetPodsInNamespace(string @namespace)
        {
           return controlers.Values.Where(p=>p.Namespace.Equals(@namespace));
        }

        public IEnumerable<Pod> GetPodsOrderedByPortThenByName()
        {
            return controlers.Values.OrderByDescending(p=>p.Port).ThenBy(p=>p.Namespace);
        }

        public int Size()=>controlers.Count;

        public void Uninstall(string podId)
        {
            if (controlers.ContainsKey(podId))
            {
                controlers.Remove(podId);
            }
            else
            {
                throw new ArgumentException();
            }
        }

        public void Upgrade(Pod pod)
        {
            if (!controlers.ContainsKey(pod.Id))
            {
                controlers.Add(pod.Id,pod);
            }
            else
            {
                Uninstall(pod.Id);
                Deploy(pod);
            }
        }
    }
}