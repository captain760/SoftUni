﻿using _01.Two_Three;

namespace Demo
{
    class Program
    {
        static void Main()
        {
            var tree = new TwoThreeTree<string>();

        }
    }
}
