﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Linq;

namespace Exam.PackageManagerLite
{
    public class PackageManager : IPackageManager
    {
        private Dictionary<string, Package> packages = new Dictionary<string, Package>();
        private Dictionary<string, Package> independants = new Dictionary<string, Package>();
        public void AddDependency(string packageId, string dependencyId)
        {
            if (!packages.ContainsKey(packageId) || !packages.ContainsKey(dependencyId))
            {
                throw new ArgumentException();
            }
            packages[packageId].Dependants.Add(packages[dependencyId]);
            if (independants.ContainsKey(dependencyId))
            {
                independants.Remove(dependencyId);
            }
        }

        public bool Contains(Package package)
        {
            return packages.ContainsKey(package.Id);
        }

        public int Count()=>packages.Count;

        public IEnumerable<Package> GetDependants(Package package)
        {
            var p = packages.Values.Where(p=>p.Dependants.Contains(package));
            return p;
        }

        public IEnumerable<Package> GetIndependentPackages()
        {
            return independants.Values.OrderByDescending(p=>p.ReleaseDate).ThenBy(p=>p.Version);
        }

        public IEnumerable<Package> GetOrderedPackagesByReleaseDateThenByVersion()
        {
            var pack = packages.Values.GroupBy(p => p.Name).Select(g=>g.OrderByDescending(x=>x.Version).First());
            return pack.OrderByDescending(p => p.ReleaseDate);
        }

        public void RegisterPackage(Package package)
        {
            foreach (var pack in packages.Values)
            {
                if (pack.Name == package.Name && pack.Version==package.Version)
                {
                    throw new ArgumentException();
                }
            }
            packages.Add(package.Id, package);
            independants.Add(package.Id, package);
        }

        public void RemovePackage(string packageId)
        {
            if (!packages.ContainsKey(packageId))
            {
                throw new ArgumentException();
            }
            var packToDelete = packages[packageId];
            var packsToDelete = packToDelete.Dependants;
            var toDelete = new HashSet<Package>();
            foreach (var item in packsToDelete)
            {
                foreach (var p in item.Dependants)
                {
                    toDelete.Add(p);
                }
            }
            toDelete.UnionWith(packsToDelete);
            foreach (var pack in toDelete)
            {
                packages.Remove(pack.Id);
            }
            packages.Remove(packageId);
            if (independants.ContainsKey(packageId))
            {
                independants.Remove(packageId);
            }
            foreach (var pack in packsToDelete)
            {
                if (independants.ContainsKey(pack.Id))
                {
                    independants.Remove(pack.Id);
                }
            }
        }
    }
}
