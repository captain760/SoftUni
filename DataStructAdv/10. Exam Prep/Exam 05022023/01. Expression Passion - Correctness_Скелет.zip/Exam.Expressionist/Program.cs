﻿using System;

namespace Exam.Expressionist
{
    internal class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
