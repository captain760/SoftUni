﻿using System;

namespace Exam.Expressionist
{
    public class Expressionist : IExpressionist
    {
        public void AddExpression(Expression expression)
        {
            throw new NotImplementedException();
        }

        public void AddExpression(Expression expression, string parentId)
        {
            throw new NotImplementedException();
        }

        public bool Contains(Expression expression)
        {
            throw new NotImplementedException();
        }

        public int Count()
        {
            throw new NotImplementedException();
        }

        public string Evaluate()
        {
            throw new NotImplementedException();
        }

        public Expression GetExpression(string expressionId)
        {
            throw new NotImplementedException();
        }

        public void RemoveExpression(string expressionId)
        {
            throw new NotImplementedException();
        }
    }
}
