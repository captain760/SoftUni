﻿namespace _01.Microsystem
{
    public enum Brand
    {
        HP = 1,
        DELL = 2,
        ASUS = 3,
        ACER = 4
    }
}
