﻿using System;

namespace Exam.MobileX
{
    public class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
