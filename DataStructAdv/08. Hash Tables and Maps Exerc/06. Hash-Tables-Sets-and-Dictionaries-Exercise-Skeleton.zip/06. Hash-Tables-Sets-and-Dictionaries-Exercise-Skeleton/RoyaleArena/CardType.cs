namespace RoyaleArena
{
    public enum CardType {
        MELEE,
        RANGED,
        SPELL,
        BUILDING
    }
}