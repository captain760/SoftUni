﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_FootballBetting.Data
{
    public enum Prediction
    {
        Draw =0,
        HomeWin = 1,
        AwayWin = 2
    }
}
