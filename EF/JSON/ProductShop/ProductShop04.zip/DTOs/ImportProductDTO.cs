﻿using Newtonsoft.Json;
using ProductShop.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ProductShop.DTOs
{
    [JsonObject]
    public class ImportProductDTO
    {
        [JsonProperty("Name")]
        [Required]
        [MinLength(GlobalConstants.MinLengthName)]
        public string Name { get; set; }
        [JsonProperty("Price")]
        [Required]
        public decimal Price { get; set; }
        [JsonProperty("SellerId")]
        [Required]
        public int SellerId { get; set; }
        [JsonProperty("BuyerId")]
        public int? BuyerId { get; set; }
    }
}
