﻿using Newtonsoft.Json;
using ProductShop.Common;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Text;

namespace ProductShop.DTOs
{
    [JsonObject]
    public class ImportCategoryDTO
    {
        [JsonProperty("name")]
        [MinLength(GlobalConstants.MinLengthName)]
        [MaxLength(GlobalConstants.MaxLengthName)]
        public string Name { get; set; }
    }
}
