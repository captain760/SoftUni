﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Data
{
    public static class Congiguration
    {
        public const string ConnectionString = @"Server=localhost;Database=ProductShop;User Id = sa; Password = yourStrong_Password";
    }
}
