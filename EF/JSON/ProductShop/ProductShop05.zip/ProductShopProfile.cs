﻿using ProductShop.DTOs.CategoryDTO;
using ProductShop.DTOs.CategoryProductDTO;
using ProductShop.DTOs.ProductDTO;
using ProductShop.DTOs.UserDTO;

using ProductShop.Models;

using AutoMapper;

namespace ProductShop
{
    public class ProductShopProfile : Profile
    {
        public ProductShopProfile()
        {
            //Imports
            this.CreateMap<ImportUserDTO, User>();
            this.CreateMap<ImportProductDTO, Product>();
            this.CreateMap<ImportCategoryDTO, Category>();
            this.CreateMap<ImportCategoryProductDTO, CategoryProduct>();

            //Exports
            this.CreateMap<Product, ExportProductInRangeDTO>()
                .ForMember(d=>d.SellerFullName,
                mo=>mo.MapFrom(s=>$"{s.Seller.FirstName} {s.Seller.LastName}"));
        }
    }
}
