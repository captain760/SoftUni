﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using AutoMapper;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.DTOs;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
        private static string filePath;  
        public static void Main(string[] args)
        {
            
            Mapper.Initialize(cfg=>cfg.AddProfile(typeof(ProductShopProfile)));
            ProductShopContext context = new ProductShopContext();

            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();
            //Console.WriteLine("Database successfully created");

            //Problem 01
            //InitializeFilePath("users.json");
            //string InputJson = File.ReadAllText(filePath);
            //string output = ImportUsers(context, InputJson);
            //Console.WriteLine(output);

            //Problem 02
            //InitializeFilePath("products.json");
            //string InputJson = File.ReadAllText(filePath);
            //string output = ImportProducts(context, InputJson);
            //Console.WriteLine(output);

            //Problem 03
            InitializeFilePath("categories.json");
            string InputJson = File.ReadAllText(filePath);
            string output = ImportCategories(context, InputJson);
            Console.WriteLine(output);

        }
        //Problem 01
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            ImportUserDTO[] userDTOs = JsonConvert.DeserializeObject < ImportUserDTO[]>(inputJson);
            ICollection<User> users = new List<User>();
            foreach (ImportUserDTO uDTO in userDTOs)
            {
                if (!IsValid(uDTO))
                {
                    continue;
                }
                User user = Mapper.Map<User>(uDTO);
                users.Add(user);
            }
            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }

        //Problem 02
        public static string ImportProducts(ProductShopContext context, string inputJson)
        {
            ImportProductDTO[] productDTOs = JsonConvert.DeserializeObject< ImportProductDTO[]>(inputJson);
            ICollection<Product> validProducts = new List<Product>();
            foreach (ImportProductDTO pDTO in productDTOs)
            {
                if (!IsValid(pDTO))
                {
                    continue;
                }
                Product product = Mapper.Map<Product>(pDTO);
                validProducts.Add(product);
            }
            context.Products.AddRange(validProducts);
            context.SaveChanges();

            return $"Successfully imported {validProducts.Count}";
        }
        //Problem 03
        public static string ImportCategories(ProductShopContext context, string inputJson)
        {
            ImportCategoryDTO[] categoryDTOs = JsonConvert.DeserializeObject<ImportCategoryDTO[]>(inputJson);
            ICollection<Category> validCategories = new List<Category>();
           
            foreach (ImportCategoryDTO cDTO in categoryDTOs)
            {
                if (!IsValid(cDTO) || cDTO.Name==null)
                {
                    continue;
                }
                Category category = Mapper.Map<Category>(cDTO);
                validCategories.Add(category);
                
            }
            context.Categories.AddRange(validCategories);
            context.SaveChanges();

            return $"Successfully imported {validCategories.Count()}";
        }

        //Problem 04

            private static bool IsValid(object obj)
        {
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(obj);
            var validationResult = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(obj,validationContext,validationResult);
            return isValid;

        }
        private static void InitializeFilePath(string fileName)
        {
            filePath =  Path.Combine(Directory.GetCurrentDirectory(), "../../../Datasets/", fileName);
        }
    }
}