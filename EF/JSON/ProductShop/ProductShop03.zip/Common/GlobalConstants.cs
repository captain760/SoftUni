﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProductShop.Common
{
    public static class GlobalConstants
    {
        public const int MinLengthName = 3;
        public const int MaxLengthName = 15;
    }
}
