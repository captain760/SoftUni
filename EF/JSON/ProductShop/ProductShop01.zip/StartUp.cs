﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using AutoMapper;
using Newtonsoft.Json;
using ProductShop.Data;
using ProductShop.DTOs;
using ProductShop.Models;

namespace ProductShop
{
    public class StartUp
    {
       
        public static void Main(string[] args)
        {
            Mapper.Initialize(cfg=>cfg.AddProfile(typeof(ProductShopProfile)));
            ProductShopContext context = new ProductShopContext();
            context.Database.EnsureDeleted();
            context.Database.EnsureCreated();
            Console.WriteLine("Database successfully created");
            string InputJson = File.ReadAllText("../../../Datasets/users.json");
            string output = ImportUsers(context, InputJson);
            Console.WriteLine(output);
        }
        public static string ImportUsers(ProductShopContext context, string inputJson)
        {
            ImportUserDTO[] userDTOs = JsonConvert.DeserializeObject < ImportUserDTO[]>(inputJson);
            ICollection<User> users = new List<User>();
            foreach (ImportUserDTO uDTO in userDTOs)
            {
                User user = Mapper.Map<User>(uDTO);
                users.Add(user);
            }
            context.Users.AddRange(users);
            context.SaveChanges();

            return $"Successfully imported {users.Count()}";
        }
    }
}