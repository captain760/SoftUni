﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using AutoMapper;
using CarDealer.Data;
using CarDealer.DTO.SupplierDTO;
using CarDealer.Models;
using Newtonsoft.Json;

namespace CarDealer
{
    public class StartUp
    {
        private static string filePath;
        public static void Main(string[] args)
        {
            Mapper.Initialize(cfg => cfg.AddProfile(typeof(CarDealerProfile)));
           CarDealerContext context = new CarDealerContext();

            //context.Database.EnsureDeleted();
            //context.Database.EnsureCreated();
            //Console.WriteLine("Database successfully created");

            //Problem 01
            InitializeDatasetsFilePath("suppliers.json");
            string InputJson = File.ReadAllText(filePath);
            string output = ImportSuppliers(context, InputJson);
            Console.WriteLine(output);

        }
        //Problem 01
        public static string ImportSuppliers(CarDealerContext context, string inputJson)
        {
            ImportSupplierDTO[] supplierDTOs = JsonConvert.DeserializeObject<ImportSupplierDTO[]>(inputJson);
            ICollection<Supplier> suppliers = new List<Supplier>();
            foreach (ImportSupplierDTO sDTO in supplierDTOs)
            {
                if (!IsValid(sDTO))
                {
                    continue;
                }
                Supplier supplier = Mapper.Map<Supplier>(sDTO);
                suppliers.Add(supplier);
            }
            context.Suppliers.AddRange(suppliers);
            context.SaveChanges();

            return $"Successfully imported {suppliers.Count}.";
        }


        private static bool IsValid(object obj)
        {
            var validationContext = new System.ComponentModel.DataAnnotations.ValidationContext(obj);
            var validationResult = new List<ValidationResult>();

            bool isValid = Validator.TryValidateObject(obj, validationContext, validationResult);
            return isValid;

        }
        private static void InitializeDatasetsFilePath(string fileName)
        {
            filePath = Path.Combine(Directory.GetCurrentDirectory(), "../../../Datasets/", fileName);
        }
        private static void InitializeOutputFilePath(string fileName)
        {
            filePath = Path.Combine(Directory.GetCurrentDirectory(), "../../../Results/", fileName);
        }
    }
}