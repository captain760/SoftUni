﻿
using AutoMapper;
using CarDealer.DTO.SupplierDTO;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            //Imports
            this.CreateMap<ImportSupplierDTO, Supplier>();
            //this.CreateMap<ImportProductDTO, Product>();
            //this.CreateMap<ImportCategoryDTO, Category>();
            //this.CreateMap<ImportCategoryProductDTO, CategoryProduct>();

            ////Exports
            //this.CreateMap<Product, ExportProductInRangeDTO>()
            //    .ForMember(d => d.SellerFullName,
            //    mo => mo.MapFrom(s => $"{s.Seller.FirstName} {s.Seller.LastName}"));
        }
    }
}
