﻿
using AutoMapper;
using CarDealer.DTO.CarsDTO;
using CarDealer.DTO.PartsDTO;
using CarDealer.DTO.SupplierDTO;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            //Imports
            this.CreateMap<ImportSupplierDTO, Supplier>();
            this.CreateMap<ImportPartsDTO, Part>();
            //this.CreateMap<ImportCarDTO, Car>();
            //this.CreateMap<ImportCategoryProductDTO, CategoryProduct>();

            ////Exports
            //this.CreateMap<Product, ExportProductInRangeDTO>()
            //    .ForMember(d => d.SellerFullName,
            //    mo => mo.MapFrom(s => $"{s.Seller.FirstName} {s.Seller.LastName}"));
        }
    }
}
