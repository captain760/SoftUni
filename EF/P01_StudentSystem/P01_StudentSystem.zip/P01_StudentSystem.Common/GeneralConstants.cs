﻿using System;

namespace P01_StudentSystem.Common
{
    public class GeneralConstants
    {
        //Student
        public const int MaxStudentName = 100;
        //Course
        public const int MaxCourseName = 80;
        //Resource
        public const int MaxResourceName = 50;
    }
}
