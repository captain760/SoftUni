﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_StudentSystem.Data
{
    public class Config
    {
        public const string ConnectionString = @"Server = localhost; Database = StudentSystem; User Id = sa; Password = yourStrong_Password"; 
    }
}
