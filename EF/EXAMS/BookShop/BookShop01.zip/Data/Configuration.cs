﻿namespace BookShop.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=BookShop;User Id = sa; Password = yourStrong_Password";
    }
}