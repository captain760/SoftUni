﻿namespace SoftJail.Data
{
   public static class Configuration
    {
        public static string ConnectionString = @"Server = localhost; Database = SoftJail; User Id = sa; Password = yourStrong_Password";
    }
}

