﻿namespace VaporStore.DataProcessor
{
	using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text;
    using System.Xml.Serialization;
    using Data;

	public static class Serializer
	{
		public static string ExportGamesByGenres(VaporStoreDbContext context, string[] genreNames)
		{
			throw new NotImplementedException();
		}

		public static string ExportUserPurchasesByType(VaporStoreDbContext context, string storeType)
		{
			throw new NotImplementedException();
		}

		private static string SerializeIt<T>(List<T> DtoT, string rootName)
		{
			XmlRootAttribute xmlRootAttribute = new XmlRootAttribute(rootName);
			XmlSerializer xmlSerializer = new XmlSerializer(typeof(List<T>), xmlRootAttribute);
			StringBuilder SBOutput = new StringBuilder();
			using StringWriter writer = new StringWriter(SBOutput);
			XmlSerializerNamespaces namespaces = new XmlSerializerNamespaces();
			namespaces.Add("", "");
			xmlSerializer.Serialize(writer, DtoT, namespaces);

			return SBOutput.ToString().TrimEnd();

		}
	}
}