﻿namespace Footballers.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server = localhost; Database = Footballers; User Id = sa; Password = yourStrong_Password";
    }
}
