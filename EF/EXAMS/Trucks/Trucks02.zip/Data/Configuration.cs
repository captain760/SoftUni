﻿namespace Trucks.Data
{
    public class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=Trucks;User Id = sa; Password = yourStrong_Password";
    }
}