﻿namespace Artillery.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=localhost;Database=Artillery;User Id = sa; Password = yourStrong_Password";
    }
}
