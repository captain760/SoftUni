﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server = localhost; Database = CarDealer; User Id = sa; Password = yourStrong_Password";
    }
}
