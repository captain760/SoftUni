﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CarDealer.Dtos.Export
{
    internal class ExportCarsDto
    {
    }
}
