﻿using AutoMapper;
using CarDealer.Dtos.Import;
using CarDealer.Models;

namespace CarDealer
{
    public class CarDealerProfile : Profile
    {
        public CarDealerProfile()
        {
            //Input
            CreateMap<ImportSupplierDTO, Supplier>();
            CreateMap<ImportPartDTO, Part>();
            CreateMap<ImportCustomerDTO, Customer>();
            CreateMap<ImportSaleDTO, Sale>();
        }
    }
}
