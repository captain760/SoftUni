﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var context = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            //Problem 02
            //string cmd = Console.ReadLine().ToLower();
            //Console.WriteLine(GetBooksByAgeRestriction(context, cmd));
            //Problem 03
            Console.WriteLine(GetGoldenBooks(context));
        }
        //Problem 02
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            
            AgeRestriction ageRestriction = new AgeRestriction();
            bool hasParsed = Enum.TryParse<AgeRestriction>(command,true,out ageRestriction);
            if (!hasParsed)
            {
                return String.Empty;
            }
            var agedBooks = context
                .Books
                .Where(b => b.AgeRestriction == ageRestriction)
                .Select(b=>b.Title)
                .OrderBy(b => b)
                .ToArray();
            string result = String.Join(Environment.NewLine, agedBooks);
            
            
            return result.ToString().TrimEnd();
        }
        //Problem 03
        public static string GetGoldenBooks(BookShopContext context)
        {
            var goldenBooks = context
                .Books
                .Where(b => b.Copies < 5000 && b.EditionType == EditionType.Gold)
                .OrderBy(b => b.BookId)
                .Select(b =>b.Title)                
                .ToArray();
            string res = String.Join(Environment.NewLine, goldenBooks);
            return res.ToString();
        }
    }
}
