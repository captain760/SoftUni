﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using System;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var db = new BookShopContext();
            //DbInitializer.ResetDatabase(db);
            //Problem 02
            string cmd = Console.ReadLine().ToLower();
            Console.WriteLine(GetBooksByAgeRestriction(db, cmd));
        }
        //Problem 02
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            //if (command != "minor" && command != "teen" && command != "adult")
            //{
            //    return String.Empty;
            //}
            
            AgeRestriction ageRestrictionEnum = Enum.Parse<AgeRestriction>(command,true);

            var agedBooks = context
                .Books
                .ToArray()
                .Where(b => b.AgeRestriction == ageRestrictionEnum)
                .OrderBy(b => b.Title)
                .ToArray();
            var sb = new StringBuilder();
            foreach (var book in agedBooks)
            {
                sb.AppendLine(book.Title);
            }
            
            
            return sb.ToString().TrimEnd();
        }
    }
}
