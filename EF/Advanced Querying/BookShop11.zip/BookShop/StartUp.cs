﻿namespace BookShop
{
    using BookShop.Models.Enums;
    using Data;
    using Initializer;
    using Microsoft.EntityFrameworkCore;
    using System;
    using System.Globalization;
    using System.Linq;
    using System.Text;

    public class StartUp
    {
        public static void Main()
        {
            using var context = new BookShopContext();
            //DbInitializer.ResetDatabase(context);
            //Problem 02
            //string cmd = Console.ReadLine().ToLower();
            //Console.WriteLine(GetBooksByAgeRestriction(context, cmd));
            //Problem 03
            //Console.WriteLine(GetGoldenBooks(context));
            //Problem 04
            //Console.WriteLine(GetBooksByPrice(context));
            //Problem 05
            //int missedYear = int.Parse(Console.ReadLine());
            //Console.WriteLine(GetBooksNotReleasedIn(context, missedYear));
            //Problem 06
            //string catValues = Console.ReadLine();
            //Console.WriteLine(GetBooksByCategory(context,catValues.ToLower()));
            //Problem 07
            //string date = Console.ReadLine();
            //Console.WriteLine(GetBooksReleasedBefore(context,date));
            //Problem 08
            //string str = Console.ReadLine();
            //Console.WriteLine(GetAuthorNamesEndingIn(context, str));
            //Problem 09
            //string str = Console.ReadLine();
            //Console.WriteLine(GetBookTitlesContaining(context, str));
            //Problem 10
            //string str = Console.ReadLine();
            //Console.WriteLine(GetBooksByAuthor(context, str));
            //Problem 11
            int lngth = int.Parse(Console.ReadLine());
            Console.WriteLine(CountBooks(context,lngth));

        }
        //Problem 02
        public static string GetBooksByAgeRestriction(BookShopContext context, string command)
        {
            
            AgeRestriction ageRestriction = new AgeRestriction();
            bool hasParsed = Enum.TryParse<AgeRestriction>(command,true,out ageRestriction);
            if (!hasParsed)
            {
                return String.Empty;
            }
            var agedBooks = context
                .Books
                .Where(b => b.AgeRestriction == ageRestriction)
                .Select(b=>b.Title)
                .OrderBy(b => b)
                .ToArray();
            string result = String.Join(Environment.NewLine, agedBooks);
            
            
            return result.ToString().TrimEnd();
        }
        //Problem 03
        public static string GetGoldenBooks(BookShopContext context)
        {
            var goldenBooks = context
                .Books
                .Where(b => b.Copies < 5000 && b.EditionType == EditionType.Gold)
                .OrderBy(b => b.BookId)
                .Select(b =>b.Title)                
                .ToArray();
            string res = String.Join(Environment.NewLine, goldenBooks);
            return res.ToString();
        }
        //Problem 04
        public static string GetBooksByPrice(BookShopContext context)
        {
            var priceBooks = context
                .Books
                .Select(b => new
                {
                    b.Title,
                    b.Price
                })
                .Where(b => b.Price > 40)
                .OrderByDescending(b => b.Price)
                .ToArray();
            var sb = new StringBuilder();
            foreach (var book in priceBooks)
            {
                sb.AppendLine($"{book.Title}  -  ${book.Price}");
            }

            return sb.ToString().TrimEnd();

        }
        //Problem 05
        public static string GetBooksNotReleasedIn(BookShopContext context, int year)
        {

            var unreleasedBooks = context
                .Books
                .OrderBy(b => b.BookId)
                .ToArray()
                .Where(b=>b.ReleaseDate.Value.Year!=year)
                //.Where(b => DateTime.Parse(b.ReleaseDate.ToString()).Year != year)
                .Select(b => b.Title)
                .ToArray();
                
            var sb = new StringBuilder();
            foreach(var book in unreleasedBooks)
            {
                sb.AppendLine(book);
            }
            return sb.ToString().TrimEnd();
        }
        //Problem 06
        public static string GetBooksByCategory(BookShopContext context, string input)
        {
            string[] cats = input
                    .Split(" ", StringSplitOptions.RemoveEmptyEntries);

            var catBook = context
                .Books
                .Where(b => b.BookCategories.Any(x=>cats.Contains(x.Category.Name.ToLower())))                
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToArray();
            return String.Join(Environment.NewLine, catBook);
        }
        //Problem 07
        public static string GetBooksReleasedBefore(BookShopContext context, string date)
        {
            DateTime limitDate = DateTime.ParseExact(date, "dd-MM-yyyy",CultureInfo.InvariantCulture);
            
            var earlyBooks = context
                .Books
                .ToList()
                .Where(b => b.ReleaseDate.Value < limitDate)
                .OrderByDescending(b => b.ReleaseDate)
                .Select(b => new
                {
                    b.Title,
                    b.EditionType,
                    b.Price
                })
                .ToList();

            var sb = new StringBuilder();
            foreach (var book in earlyBooks)
            {
                sb.AppendLine($"{book.Title} - {book.EditionType} - ${book.Price}");
            }
            return sb.ToString().TrimEnd();
        }
        //Problem 08
        public static string GetAuthorNamesEndingIn(BookShopContext context, string input)
        {
            var chosenAuthors = context
                .Authors
                .ToArray()
                .Where(a=>a.FirstName.ToString().EndsWith(input))
                .Select(a => new
                {
                    a.FirstName,
                    a.LastName
                })
                .OrderBy(a=>a.FirstName)
                .ThenBy(a=>a.LastName)
                .ToArray();
            var sb = new StringBuilder();
            foreach (var author in chosenAuthors)
            {
                string fullName = $"{author.FirstName} {author.LastName}";
                sb.AppendLine(fullName);
            }
            return sb.ToString().TrimEnd();
        }
        //Problem 09
        public static string GetBookTitlesContaining(BookShopContext context, string input)
        {
            var serchedBooks = context
                .Books
                .ToArray()
                .Where(b => b.Title.ToLower().Contains(input.ToLower()))
                .Select(b => b.Title)
                .OrderBy(b => b)
                .ToArray();
            return String.Join(Environment.NewLine,serchedBooks).ToString().TrimEnd();
        }
        //Problem 10
        public static string GetBooksByAuthor(BookShopContext context, string input)
        {
            var booksByAuthor = context
                .Books                
                .ToArray()
                .Where(b => b.Author.LastName.ToLower().StartsWith(input.ToLower()))
                .OrderBy(b => b.BookId)
                .Select(b => new
                {
                    b.Title,
                    b.Author.FirstName,
                    b.Author.LastName,

                })
                .ToArray();
            var sb = new StringBuilder();
            foreach (var Book in booksByAuthor)
            {
                sb.AppendLine($"{Book.Title} ({Book.FirstName} {Book.LastName})");
            }
            return sb.ToString().TrimEnd();
        }
        //Problem 11
        public static int CountBooks(BookShopContext context, int lengthCheck)
        {
            var longBooks = context
                .Books
                .Where(b => b.Title.Length > lengthCheck).
                Select(b => b.BookId)
                .ToArray();
            return longBooks.Length;
        }
    }
}
