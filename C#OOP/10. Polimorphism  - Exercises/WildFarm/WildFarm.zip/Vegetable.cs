﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public class Vegetable : IEatable
    {
        
        public int Quantity { get ; set ; }
    }
}
