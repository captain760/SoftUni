﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WildFarm
{
    public class Fruit : IEatable
    {
        public int Quantity { get ; set ; }
    }
}
