﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public class Car : Vehicle
    {
        public Car(double fuelQuantity, double consumption):base(fuelQuantity,consumption)
        {
            FuelQuantity = fuelQuantity;
            Consumption = consumption;
        }

        public override double FuelQuantity { get ; set ; }
        public override double Consumption { get ; set ; }

        public override void Drive(double distance)
        {
            double requiredFuel = distance*(Consumption+0.9);
            if (FuelQuantity>=requiredFuel)
            {
                FuelQuantity -= requiredFuel;
                Console.WriteLine($"Car travelled {distance} km");
            }
            else
            {
                Console.WriteLine("Car needs refueling");
            }
        }

        public override void Refuel(double fuel)
        {
            FuelQuantity+=fuel;
        }
    }
}
