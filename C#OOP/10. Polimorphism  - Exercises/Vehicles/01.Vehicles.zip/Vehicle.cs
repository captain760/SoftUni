﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Vehicles
{
    public abstract class Vehicle
    {
        protected Vehicle(double fuelQuantity, double consumption)
        {
            FuelQuantity = fuelQuantity;
            Consumption = consumption;
        }

        public abstract double FuelQuantity { get; set; }
        public abstract double Consumption { get; set; }
        public abstract void Drive(double distance);

        public abstract void Refuel(double fuel);
       
    }
}
