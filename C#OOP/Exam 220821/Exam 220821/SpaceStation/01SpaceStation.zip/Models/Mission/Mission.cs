﻿using SpaceStation.Models.Astronauts.Contracts;
using SpaceStation.Models.Mission.Contracts;
using SpaceStation.Models.Planets;
using SpaceStation.Models.Planets.Contracts;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SpaceStation.Models.Mission
{
    public class Mission : IMission
    {
        public void Explore(IPlanet planet, ICollection<IAstronaut> astronauts)
        {
            foreach (var astronaut in astronauts)
            {
                while (astronaut.CanBreath)
                {
                    if (planet.Items.LastOrDefault() != null)
                    {
                        string item = planet.Items.LastOrDefault();
                        astronaut.Breath();
                        if (astronaut.Oxygen == 0)
                        {
                            break;
                        }
                        astronaut.Bag.Items.Add(item);
                        planet.Items.Remove(item);


                    }
                    else
                    {
                        break;
                    }

                }
                if (planet.Items.LastOrDefault() != null)
                {
                    break;
                }
            }
            //IAstronaut currentAstronaut = astronauts.FirstOrDefault();
            //Planet currentPlanet = planet as Planet;

            //while (currentAstronaut != null && currentPlanet.Items.Count > 0)
            //{
            //    while (currentAstronaut.CanBreath)
            //    {
            //        if (currentPlanet.Items.Count > 0)
            //        {
            //            currentAstronaut.Breath();
            //            string temp = currentPlanet.items[0];
            //            currentPlanet.items.RemoveAt(0);

            //            currentAstronaut.Bag.Items.Add(temp);
            //        }
            //        else
            //        {
            //            break;
            //        }
            //    }

            //    if (!currentAstronaut.CanBreath)
            //    {
            //        astronauts.Remove(currentAstronaut);
            //        currentAstronaut = astronauts.FirstOrDefault();
            //    }
            //}
        }
    }
}
