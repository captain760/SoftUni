﻿using OnlineShop.Common.Constants;
using OnlineShop.Models.Products.Peripherals;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace OnlineShop.Models.Products.Computers
{
    public abstract class Computer : Product, IComputer
    {
        private List<Components.IComponent> components;
        private List<IPeripheral> peripherals;
        private double performance;
        private decimal price;
        public Computer(int id, string manufacturer, string model, decimal price, double overallPerformance) : base(id, manufacturer, model, price, overallPerformance)
        {
            components = new List<Components.IComponent>();
            peripherals = new List<IPeripheral>();
            
        }
        IReadOnlyCollection<Components.IComponent> IComputer.Components => components;

        IReadOnlyCollection<IPeripheral> IComputer.Peripherals => peripherals;

        public override double OverallPerformance
        {
            get 
            {
                return performance;
            }
            set
            {
                if (this.components.Count == 0)
                {
                    performance = base.OverallPerformance;
                }
                else
                {

                    performance = base.OverallPerformance + this.components.Average(x => x.OverallPerformance);
                }
            }
	    }
        public override decimal Price 
        {
            get
            {
                return price;
            }
            set
            {
                price = base.Price + components.Sum(x => x.Price) + peripherals.Sum(x => x.Price);
            }
        }


        public void AddComponent(Components.IComponent component)
        {
            if (components.Any(x=>x.GetType().Name == component.GetType().Name))
            {
                throw new ArgumentException(string.Format(ExceptionMessages.ExistingComponent, component.GetType().Name, this.GetType().Name, this.Id.GetType().Name));
            }
            components.Add(component);
        }

        public void AddPeripheral(IPeripheral peripheral)
        {
            if (peripherals.Any(x => x.GetType().Name == peripheral.GetType().Name))
            {
                throw new ArgumentException(string.Format(ExceptionMessages.ExistingPeripheral, peripheral.GetType().Name, this.GetType().Name, this.Id.GetType().Name));
            }
            peripherals.Add(peripheral);
        }

        public Components.IComponent RemoveComponent(string componentType)
        {
            if (components.Count ==0 || !components.Any(x=>x.GetType().Name == componentType))
            {
                throw new ArgumentException(string.Format(ExceptionMessages.NotExistingComponent, componentType, this.GetType().Name, this.Id.GetType().Name));
            }
            Components.IComponent removed = components.First(x => x.GetType().Name == componentType);
            components.Remove(removed);
            return removed;
        }

        public IPeripheral RemovePeripheral(string peripheralType)
        {
            if (peripherals.Count == 0 || !peripherals.Any(x => x.GetType().Name == peripheralType))
            {
                throw new ArgumentException(string.Format(ExceptionMessages.NotExistingPeripheral, peripheralType, this.GetType().Name, this.Id.GetType().Name));
            }
            IPeripheral removed = peripherals.First(x => x.GetType().Name == peripheralType);
            peripherals.Remove(removed);
            return removed;
        }

        public override string ToString()
        {
            var sb = new StringBuilder();
            sb.AppendLine($"Overall Performance: {this.OverallPerformance}. Price: {Price} - {this.GetType().Name}: {Manufacturer} {Model} (Id: {Id})");
            sb.AppendLine($" Components ({components.Count}):");
            foreach (var item in components)
            {
                
                sb.AppendLine(item.ToString());
            }
            sb.AppendLine($" Peripherals ({peripherals.Count}); Average Overall Performance ({peripherals.Select(x => x.OverallPerformance).Average()}):");
            foreach (var item in peripherals)
            {
                
                sb.AppendLine(item.ToString());
            }
            return sb.ToString().TrimEnd();
        }
    }
}
